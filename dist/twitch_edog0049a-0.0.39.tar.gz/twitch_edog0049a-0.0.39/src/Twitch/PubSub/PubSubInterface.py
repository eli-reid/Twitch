class PubSubInterface:
    pass