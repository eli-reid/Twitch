from ..WebsocketClient.WebsocketClient import WebsocketClient

class EventSubConnector:
    def __init__(self) -> None:
        pass