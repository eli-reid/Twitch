
from Twitch.ChatInterface.MessageHandler import Message as MessageType
from Twitch.ChatInterface.TwitchChatInterface import TCI as Chat