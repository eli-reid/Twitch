from Twitch.API.Resources import Utils
from Twitch import Scope
from Twitch import SubscriptionTypes as SubType
from typing import Optional, Any, TypeVar, Type, List, Union, TypeAlias, Dict
from datetime import datetime