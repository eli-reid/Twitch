class Chat:
    pass