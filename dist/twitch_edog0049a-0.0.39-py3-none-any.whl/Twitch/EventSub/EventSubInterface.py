class EventSubInterface:
    def __init__(self) -> None:
        pass