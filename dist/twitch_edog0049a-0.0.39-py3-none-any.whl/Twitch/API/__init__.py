from Twitch.API.TwitchAPI import twitchAPI as Requests, Credentials
from Twitch.API.Resources import ResponseTypes
from Twitch.API import Exceptions
from Twitch import Scope