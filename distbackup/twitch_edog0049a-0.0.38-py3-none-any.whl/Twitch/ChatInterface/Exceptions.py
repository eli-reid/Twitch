class InvalidMessageError(Exception):
    pass
class InvalidLoginError(Exception):
    pass